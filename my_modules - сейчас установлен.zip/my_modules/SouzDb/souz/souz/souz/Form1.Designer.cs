﻿namespace souz
{
    partial class FMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
        this.components = new System.ComponentModel.Container();
        System.Windows.Forms.Label fIOLabel;
        System.Windows.Forms.Label cOMMENTLabel;
        System.Windows.Forms.Label oPLATA_DOLabel;
        System.Windows.Forms.Label iNS_DATELabel;
        System.Windows.Forms.Label label13;
        System.Windows.Forms.Label label14;
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
        this.menuStrip1 = new System.Windows.Forms.MenuStrip();
        this.dataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.экспортВКвитанцииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.экспорт2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.serviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.начатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.начатьРаботуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.statusStrip1 = new System.Windows.Forms.StatusStrip();
        this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.splitContainer1 = new System.Windows.Forms.SplitContainer();
        this.checkBox2 = new System.Windows.Forms.CheckBox();
        this.groupBox10 = new System.Windows.Forms.GroupBox();
        this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
        this.label5 = new System.Windows.Forms.Label();
        this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
        this.label6 = new System.Windows.Forms.Label();
        this.checkBox1 = new System.Windows.Forms.CheckBox();
        this.button1 = new System.Windows.Forms.Button();
        this.groupBox13 = new System.Windows.Forms.GroupBox();
        this.comboBox3 = new System.Windows.Forms.ComboBox();
        this.label8 = new System.Windows.Forms.Label();
        this.groupBox2 = new System.Windows.Forms.GroupBox();
        this.radioButton3 = new System.Windows.Forms.RadioButton();
        this.radioButton2 = new System.Windows.Forms.RadioButton();
        this.radioButton1 = new System.Windows.Forms.RadioButton();
        this.groupBox4 = new System.Windows.Forms.GroupBox();
        this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
        this.groupBox12 = new System.Windows.Forms.GroupBox();
        this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
        this.label7 = new System.Windows.Forms.Label();
        this.groupBox9 = new System.Windows.Forms.GroupBox();
        this.label10 = new System.Windows.Forms.Label();
        this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
        this.label3 = new System.Windows.Forms.Label();
        this.label4 = new System.Windows.Forms.Label();
        this.textBox3 = new System.Windows.Forms.TextBox();
        this.comboBox2 = new System.Windows.Forms.ComboBox();
        this.radioButton4 = new System.Windows.Forms.RadioButton();
        this.radioButton7 = new System.Windows.Forms.RadioButton();
        this.groupBox5 = new System.Windows.Forms.GroupBox();
        this.textBox1 = new System.Windows.Forms.TextBox();
        this.groupBox11 = new System.Windows.Forms.GroupBox();
        this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
        this.label9 = new System.Windows.Forms.Label();
        this.groupBox3 = new System.Windows.Forms.GroupBox();
        this.radioButton5 = new System.Windows.Forms.RadioButton();
        this.comboBox1 = new System.Windows.Forms.ComboBox();
        this.radioButton6 = new System.Windows.Forms.RadioButton();
        this.label1 = new System.Windows.Forms.Label();
        this.splitContainer2 = new System.Windows.Forms.SplitContainer();
        this.selLSBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
        this.selLSBindingSource = new System.Windows.Forms.BindingSource(this.components);
        this.archiveDataSet = new souz.archiveDataSet();
        this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
        this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
        this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
        this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
        this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
        this.selLSBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
        this.groupBox6 = new System.Windows.Forms.GroupBox();
        this.selLSDataGridView = new System.Windows.Forms.DataGridView();
        this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.LS = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.SAL1W = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.SAL2W = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.ITGNW = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.spZEU_NAIM = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.spUL_NAIM = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.DOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.DOML = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.DOMP = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.KV = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.KVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.PEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.NZEU = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.OPLATA_DO = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.DOLG_POSLE_OPLATY = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.fIODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.dOMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.dOMLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.dOMPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.kVDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.kVLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.lSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.nZEUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.uLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.sAL2WDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.iTGNWDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.sAL1WDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.oPLATADODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.iNSDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.cOMMENTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.lSXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.pENDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.spULNAIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.spZEUNAIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.streetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.companyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.label2 = new System.Windows.Forms.Label();
        this.groupBox8 = new System.Windows.Forms.GroupBox();
        this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
        this.label15 = new System.Windows.Forms.Label();
        this.button2 = new System.Windows.Forms.Button();
        this.label12 = new System.Windows.Forms.Label();
        this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
        this.textBox2 = new System.Windows.Forms.TextBox();
        this.richTextBox2 = new System.Windows.Forms.RichTextBox();
        this.label11 = new System.Windows.Forms.Label();
        this.groupBox7 = new System.Windows.Forms.GroupBox();
        this.button3 = new System.Windows.Forms.Button();
        this.iNS_DATETextBox = new System.Windows.Forms.TextBox();
        this.oPLATA_DOTextBox = new System.Windows.Forms.TextBox();
        this.cOMMENTRichTextBox = new System.Windows.Forms.RichTextBox();
        this.fIOLabel1 = new System.Windows.Forms.Label();
        this.richTextBox1 = new System.Windows.Forms.RichTextBox();
        this.selLSTableAdapter = new souz.archiveDataSetTableAdapters.selLSTableAdapter();
        this.tableAdapterManager = new souz.archiveDataSetTableAdapters.TableAdapterManager();
        this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
        this.timer1 = new System.Windows.Forms.Timer(this.components);
        fIOLabel = new System.Windows.Forms.Label();
        cOMMENTLabel = new System.Windows.Forms.Label();
        oPLATA_DOLabel = new System.Windows.Forms.Label();
        iNS_DATELabel = new System.Windows.Forms.Label();
        label13 = new System.Windows.Forms.Label();
        label14 = new System.Windows.Forms.Label();
        this.menuStrip1.SuspendLayout();
        this.statusStrip1.SuspendLayout();
        this.groupBox1.SuspendLayout();
        this.splitContainer1.Panel1.SuspendLayout();
        this.splitContainer1.Panel2.SuspendLayout();
        this.splitContainer1.SuspendLayout();
        this.groupBox10.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
        this.groupBox13.SuspendLayout();
        this.groupBox2.SuspendLayout();
        this.groupBox4.SuspendLayout();
        this.groupBox12.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
        this.groupBox9.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
        this.groupBox5.SuspendLayout();
        this.groupBox11.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
        this.groupBox3.SuspendLayout();
        this.splitContainer2.Panel1.SuspendLayout();
        this.splitContainer2.Panel2.SuspendLayout();
        this.splitContainer2.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.selLSBindingNavigator)).BeginInit();
        this.selLSBindingNavigator.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.selLSBindingSource)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.archiveDataSet)).BeginInit();
        this.groupBox6.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.selLSDataGridView)).BeginInit();
        this.groupBox8.SuspendLayout();
        this.groupBox7.SuspendLayout();
        this.SuspendLayout();
        // 
        // fIOLabel
        // 
        fIOLabel.AutoSize = true;
        fIOLabel.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        fIOLabel.Location = new System.Drawing.Point(9, 19);
        fIOLabel.Name = "fIOLabel";
        fIOLabel.Size = new System.Drawing.Size(35, 13);
        fIOLabel.TabIndex = 0;
        fIOLabel.Text = "ФИО:";
        // 
        // cOMMENTLabel
        // 
        cOMMENTLabel.AutoSize = true;
        cOMMENTLabel.Location = new System.Drawing.Point(9, 36);
        cOMMENTLabel.Name = "cOMMENTLabel";
        cOMMENTLabel.Size = new System.Drawing.Size(124, 13);
        cOMMENTLabel.TabIndex = 2;
        cOMMENTLabel.Text = "Текущий комментарий:";
        // 
        // oPLATA_DOLabel
        // 
        oPLATA_DOLabel.Location = new System.Drawing.Point(9, 117);
        oPLATA_DOLabel.Name = "oPLATA_DOLabel";
        oPLATA_DOLabel.Size = new System.Drawing.Size(107, 35);
        oPLATA_DOLabel.TabIndex = 4;
        oPLATA_DOLabel.Text = "Оплатить до:";
        // 
        // iNS_DATELabel
        // 
        iNS_DATELabel.Location = new System.Drawing.Point(9, 149);
        iNS_DATELabel.Name = "iNS_DATELabel";
        iNS_DATELabel.Size = new System.Drawing.Size(107, 36);
        iNS_DATELabel.TabIndex = 6;
        iNS_DATELabel.Text = "Дата уст-ки ком-рия:";
        // 
        // label13
        // 
        label13.AutoEllipsis = true;
        label13.AutoSize = true;
        label13.Location = new System.Drawing.Point(9, 99);
        label13.Name = "label13";
        label13.Size = new System.Drawing.Size(83, 13);
        label13.TabIndex = 4;
        label13.Text = "Оплатить до:*";
        // 
        // label14
        // 
        label14.AutoSize = true;
        label14.Location = new System.Drawing.Point(9, 19);
        label14.Name = "label14";
        label14.Size = new System.Drawing.Size(166, 13);
        label14.TabIndex = 2;
        label14.Text = "Комментарий (необязательно):";
        // 
        // menuStrip1
        // 
        this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataToolStripMenuItem,
            this.serviceToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.начатьToolStripMenuItem});
        this.menuStrip1.Location = new System.Drawing.Point(0, 0);
        this.menuStrip1.Name = "menuStrip1";
        this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
        this.menuStrip1.Size = new System.Drawing.Size(865, 24);
        this.menuStrip1.TabIndex = 0;
        this.menuStrip1.Text = "menuStrip1";
        // 
        // dataToolStripMenuItem
        // 
        this.dataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.экспортВКвитанцииToolStripMenuItem,
            this.экспорт2ToolStripMenuItem});
        this.dataToolStripMenuItem.Name = "dataToolStripMenuItem";
        this.dataToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
        this.dataToolStripMenuItem.Text = "Данные";
        // 
        // loadToolStripMenuItem
        // 
        this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
        this.loadToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
        this.loadToolStripMenuItem.Text = "Загрузить из общей базы/обновить архив";
        this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
        // 
        // экспортВКвитанцииToolStripMenuItem
        // 
        this.экспортВКвитанцииToolStripMenuItem.Name = "экспортВКвитанцииToolStripMenuItem";
        this.экспортВКвитанцииToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
        this.экспортВКвитанцииToolStripMenuItem.Text = "Экспорт в квитанции (шаблон Ms Word)";
        this.экспортВКвитанцииToolStripMenuItem.Click += new System.EventHandler(this.экспортВКвитанцииToolStripMenuItem_Click);
        // 
        // экспорт2ToolStripMenuItem
        // 
        this.экспорт2ToolStripMenuItem.Name = "экспорт2ToolStripMenuItem";
        this.экспорт2ToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
        this.экспорт2ToolStripMenuItem.Text = "Экспорт (в разработке)";
        this.экспорт2ToolStripMenuItem.Visible = false;
        this.экспорт2ToolStripMenuItem.Click += new System.EventHandler(this.экспорт2ToolStripMenuItem_Click);
        // 
        // serviceToolStripMenuItem
        // 
        this.serviceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem});
        this.serviceToolStripMenuItem.Name = "serviceToolStripMenuItem";
        this.serviceToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
        this.serviceToolStripMenuItem.Text = "Сервис";
        // 
        // settingsToolStripMenuItem
        // 
        this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
        this.settingsToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
        this.settingsToolStripMenuItem.Text = "Настройки";
        this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
        // 
        // helpToolStripMenuItem
        // 
        this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
        this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
        this.helpToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
        this.helpToolStripMenuItem.Text = "Справка";
        // 
        // оПрограммеToolStripMenuItem
        // 
        this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
        this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
        this.оПрограммеToolStripMenuItem.Text = "О программе";
        this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
        // 
        // начатьToolStripMenuItem
        // 
        this.начатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.начатьРаботуToolStripMenuItem});
        this.начатьToolStripMenuItem.Name = "начатьToolStripMenuItem";
        this.начатьToolStripMenuItem.Size = new System.Drawing.Size(107, 20);
        this.начатьToolStripMenuItem.Text = "Дополнительно";
        // 
        // начатьРаботуToolStripMenuItem
        // 
        this.начатьРаботуToolStripMenuItem.Name = "начатьРаботуToolStripMenuItem";
        this.начатьРаботуToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
        this.начатьРаботуToolStripMenuItem.Text = "Подключить справочники";
        this.начатьРаботуToolStripMenuItem.Click += new System.EventHandler(this.начатьРаботуToolStripMenuItem_Click);
        // 
        // statusStrip1
        // 
        this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
        this.statusStrip1.Location = new System.Drawing.Point(0, 608);
        this.statusStrip1.Name = "statusStrip1";
        this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 12, 0);
        this.statusStrip1.Size = new System.Drawing.Size(865, 22);
        this.statusStrip1.TabIndex = 1;
        this.statusStrip1.Text = "statusStrip1";
        // 
        // toolStripStatusLabel1
        // 
        this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
        this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.splitContainer1);
        this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
        this.groupBox1.Location = new System.Drawing.Point(0, 24);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(865, 584);
        this.groupBox1.TabIndex = 2;
        this.groupBox1.TabStop = false;
        // 
        // splitContainer1
        // 
        this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
        this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
        this.splitContainer1.Location = new System.Drawing.Point(3, 16);
        this.splitContainer1.Name = "splitContainer1";
        // 
        // splitContainer1.Panel1
        // 
        this.splitContainer1.Panel1.AutoScroll = true;
        this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control;
        this.splitContainer1.Panel1.Controls.Add(this.checkBox2);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox10);
        this.splitContainer1.Panel1.Controls.Add(this.checkBox1);
        this.splitContainer1.Panel1.Controls.Add(this.button1);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox13);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox4);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox12);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox9);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox5);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox11);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
        this.splitContainer1.Panel1.Controls.Add(this.label1);
        // 
        // splitContainer1.Panel2
        // 
        this.splitContainer1.Panel2.AutoScroll = true;
        this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Window;
        this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
        this.splitContainer1.Size = new System.Drawing.Size(859, 565);
        this.splitContainer1.SplitterDistance = 288;
        this.splitContainer1.TabIndex = 0;
        // 
        // checkBox2
        // 
        this.checkBox2.AutoSize = true;
        this.checkBox2.Location = new System.Drawing.Point(159, 12);
        this.checkBox2.Name = "checkBox2";
        this.checkBox2.Size = new System.Drawing.Size(80, 17);
        this.checkBox2.TabIndex = 21;
        this.checkBox2.Text = "Как в KVPL";
        this.checkBox2.UseVisualStyleBackColor = true;
        this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
        // 
        // groupBox10
        // 
        this.groupBox10.Controls.Add(this.numericUpDown3);
        this.groupBox10.Controls.Add(this.label5);
        this.groupBox10.Controls.Add(this.numericUpDown2);
        this.groupBox10.Controls.Add(this.label6);
        this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox10.Location = new System.Drawing.Point(10, 397);
        this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox10.Name = "groupBox10";
        this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox10.Size = new System.Drawing.Size(269, 53);
        this.groupBox10.TabIndex = 20;
        this.groupBox10.TabStop = false;
        this.groupBox10.Text = "Итого начислено";
        // 
        // numericUpDown3
        // 
        this.numericUpDown3.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown3.Location = new System.Drawing.Point(170, 20);
        this.numericUpDown3.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown3.Name = "numericUpDown3";
        this.numericUpDown3.Size = new System.Drawing.Size(93, 20);
        this.numericUpDown3.TabIndex = 6;
        this.numericUpDown3.Validated += new System.EventHandler(this.numericUpDown2_Validated);
        // 
        // label5
        // 
        this.label5.AutoSize = true;
        this.label5.Location = new System.Drawing.Point(138, 20);
        this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label5.Name = "label5";
        this.label5.Size = new System.Drawing.Size(24, 13);
        this.label5.TabIndex = 5;
        this.label5.Text = "До";
        // 
        // numericUpDown2
        // 
        this.numericUpDown2.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown2.Location = new System.Drawing.Point(37, 20);
        this.numericUpDown2.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown2.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown2.Name = "numericUpDown2";
        this.numericUpDown2.Size = new System.Drawing.Size(94, 20);
        this.numericUpDown2.TabIndex = 4;
        this.numericUpDown2.Validated += new System.EventHandler(this.numericUpDown2_Validated);
        // 
        // label6
        // 
        this.label6.AutoSize = true;
        this.label6.Location = new System.Drawing.Point(7, 20);
        this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label6.Name = "label6";
        this.label6.Size = new System.Drawing.Size(22, 13);
        this.label6.TabIndex = 3;
        this.label6.Text = "От";
        // 
        // checkBox1
        // 
        this.checkBox1.AutoSize = true;
        this.checkBox1.Location = new System.Drawing.Point(13, 503);
        this.checkBox1.Name = "checkBox1";
        this.checkBox1.Size = new System.Drawing.Size(251, 17);
        this.checkBox1.TabIndex = 19;
        this.checkBox1.Text = "Только с ком-ем, если СальдоК > Уст.долга";
        this.checkBox1.UseVisualStyleBackColor = true;
        // 
        // button1
        // 
        this.button1.Font = new System.Drawing.Font("Tahoma", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.button1.Location = new System.Drawing.Point(9, 530);
        this.button1.Name = "button1";
        this.button1.Size = new System.Drawing.Size(271, 24);
        this.button1.TabIndex = 18;
        this.button1.Text = "Поиск!";
        this.button1.UseVisualStyleBackColor = true;
        this.button1.Click += new System.EventHandler(this.button1_Click);
        // 
        // groupBox13
        // 
        this.groupBox13.Controls.Add(this.comboBox3);
        this.groupBox13.Controls.Add(this.label8);
        this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox13.Location = new System.Drawing.Point(10, 448);
        this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox13.Name = "groupBox13";
        this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox13.Size = new System.Drawing.Size(269, 48);
        this.groupBox13.TabIndex = 17;
        this.groupBox13.TabStop = false;
        this.groupBox13.Text = "Упорядочить";
        // 
        // comboBox3
        // 
        this.comboBox3.FormattingEnabled = true;
        this.comboBox3.Items.AddRange(new object[] {
            "Адрес (Улица и номер дома)",
            "НачислИтг(Долг)",
            "ФИО"});
        this.comboBox3.Location = new System.Drawing.Point(35, 19);
        this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox3.Name = "comboBox3";
        this.comboBox3.Size = new System.Drawing.Size(229, 21);
        this.comboBox3.TabIndex = 4;
        // 
        // label8
        // 
        this.label8.AutoSize = true;
        this.label8.Location = new System.Drawing.Point(7, 24);
        this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label8.Name = "label8";
        this.label8.Size = new System.Drawing.Size(21, 13);
        this.label8.TabIndex = 3;
        this.label8.Text = "по";
        // 
        // groupBox2
        // 
        this.groupBox2.Controls.Add(this.radioButton3);
        this.groupBox2.Controls.Add(this.radioButton2);
        this.groupBox2.Controls.Add(this.radioButton1);
        this.groupBox2.Location = new System.Drawing.Point(10, 352);
        this.groupBox2.Name = "groupBox2";
        this.groupBox2.Size = new System.Drawing.Size(269, 44);
        this.groupBox2.TabIndex = 1;
        this.groupBox2.TabStop = false;
        this.groupBox2.Text = "Выберите тип помещения";
        // 
        // radioButton3
        // 
        this.radioButton3.AutoSize = true;
        this.radioButton3.Location = new System.Drawing.Point(169, 21);
        this.radioButton3.Name = "radioButton3";
        this.radioButton3.Size = new System.Drawing.Size(59, 17);
        this.radioButton3.TabIndex = 2;
        this.radioButton3.Text = "Любое";
        this.radioButton3.UseVisualStyleBackColor = true;
        // 
        // radioButton2
        // 
        this.radioButton2.AutoSize = true;
        this.radioButton2.Location = new System.Drawing.Point(83, 21);
        this.radioButton2.Name = "radioButton2";
        this.radioButton2.Size = new System.Drawing.Size(70, 17);
        this.radioButton2.TabIndex = 1;
        this.radioButton2.Text = "Нежилое";
        this.radioButton2.UseVisualStyleBackColor = true;
        // 
        // radioButton1
        // 
        this.radioButton1.AutoSize = true;
        this.radioButton1.Checked = true;
        this.radioButton1.Location = new System.Drawing.Point(7, 21);
        this.radioButton1.Name = "radioButton1";
        this.radioButton1.Size = new System.Drawing.Size(59, 17);
        this.radioButton1.TabIndex = 0;
        this.radioButton1.TabStop = true;
        this.radioButton1.Text = "Жилое";
        this.radioButton1.UseVisualStyleBackColor = true;
        // 
        // groupBox4
        // 
        this.groupBox4.Controls.Add(this.maskedTextBox1);
        this.groupBox4.Location = new System.Drawing.Point(10, 32);
        this.groupBox4.Name = "groupBox4";
        this.groupBox4.Size = new System.Drawing.Size(269, 53);
        this.groupBox4.TabIndex = 3;
        this.groupBox4.TabStop = false;
        this.groupBox4.Text = "Номер лиц счета";
        // 
        // maskedTextBox1
        // 
        this.maskedTextBox1.BeepOnError = true;
        this.maskedTextBox1.Location = new System.Drawing.Point(7, 22);
        this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(4);
        this.maskedTextBox1.Mask = "000000000000000000";
        this.maskedTextBox1.Name = "maskedTextBox1";
        this.maskedTextBox1.PromptChar = '.';
        this.maskedTextBox1.Size = new System.Drawing.Size(255, 20);
        this.maskedTextBox1.TabIndex = 7;
        this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // groupBox12
        // 
        this.groupBox12.Controls.Add(this.numericUpDown4);
        this.groupBox12.Controls.Add(this.label7);
        this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox12.Location = new System.Drawing.Point(149, 85);
        this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox12.Name = "groupBox12";
        this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox12.Size = new System.Drawing.Size(130, 48);
        this.groupBox12.TabIndex = 16;
        this.groupBox12.TabStop = false;
        this.groupBox12.Text = "Сальдо к";
        // 
        // numericUpDown4
        // 
        this.numericUpDown4.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown4.Location = new System.Drawing.Point(38, 18);
        this.numericUpDown4.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown4.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown4.Name = "numericUpDown4";
        this.numericUpDown4.Size = new System.Drawing.Size(87, 20);
        this.numericUpDown4.TabIndex = 4;
        this.numericUpDown4.Validated += new System.EventHandler(this.numericUpDown2_Validated);
        // 
        // label7
        // 
        this.label7.AutoSize = true;
        this.label7.Location = new System.Drawing.Point(7, 20);
        this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label7.Name = "label7";
        this.label7.Size = new System.Drawing.Size(22, 13);
        this.label7.TabIndex = 3;
        this.label7.Text = "От";
        // 
        // groupBox9
        // 
        this.groupBox9.Controls.Add(this.label10);
        this.groupBox9.Controls.Add(this.numericUpDown1);
        this.groupBox9.Controls.Add(this.label3);
        this.groupBox9.Controls.Add(this.label4);
        this.groupBox9.Controls.Add(this.textBox3);
        this.groupBox9.Controls.Add(this.comboBox2);
        this.groupBox9.Controls.Add(this.radioButton4);
        this.groupBox9.Controls.Add(this.radioButton7);
        this.groupBox9.Location = new System.Drawing.Point(10, 188);
        this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox9.Name = "groupBox9";
        this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox9.Size = new System.Drawing.Size(269, 109);
        this.groupBox9.TabIndex = 12;
        this.groupBox9.TabStop = false;
        this.groupBox9.Text = "Адрес";
        // 
        // label10
        // 
        this.label10.AutoSize = true;
        this.label10.Location = new System.Drawing.Point(7, 81);
        this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label10.Name = "label10";
        this.label10.Size = new System.Drawing.Size(27, 13);
        this.label10.TabIndex = 16;
        this.label10.Text = "Дом";
        // 
        // numericUpDown1
        // 
        this.numericUpDown1.Location = new System.Drawing.Point(82, 79);
        this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
        this.numericUpDown1.Name = "numericUpDown1";
        this.numericUpDown1.Size = new System.Drawing.Size(66, 20);
        this.numericUpDown1.TabIndex = 15;
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(151, 81);
        this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(14, 13);
        this.label3.TabIndex = 14;
        this.label3.Text = "К";
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Location = new System.Drawing.Point(50, 81);
        this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(20, 13);
        this.label4.TabIndex = 13;
        this.label4.Text = "№";
        // 
        // textBox3
        // 
        this.textBox3.Location = new System.Drawing.Point(170, 78);
        this.textBox3.Margin = new System.Windows.Forms.Padding(4);
        this.textBox3.Name = "textBox3";
        this.textBox3.Size = new System.Drawing.Size(32, 20);
        this.textBox3.TabIndex = 12;
        // 
        // comboBox2
        // 
        this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBox2.Enabled = false;
        this.comboBox2.FormattingEnabled = true;
        this.comboBox2.Location = new System.Drawing.Point(7, 49);
        this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox2.MaxDropDownItems = 12;
        this.comboBox2.Name = "comboBox2";
        this.comboBox2.Size = new System.Drawing.Size(256, 20);
        this.comboBox2.TabIndex = 11;
        // 
        // radioButton4
        // 
        this.radioButton4.AutoSize = true;
        this.radioButton4.Location = new System.Drawing.Point(128, 20);
        this.radioButton4.Margin = new System.Windows.Forms.Padding(4);
        this.radioButton4.Name = "radioButton4";
        this.radioButton4.Size = new System.Drawing.Size(85, 17);
        this.radioButton4.TabIndex = 3;
        this.radioButton4.TabStop = true;
        this.radioButton4.Text = "Выбранная:";
        this.radioButton4.UseVisualStyleBackColor = true;
        this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
        // 
        // radioButton7
        // 
        this.radioButton7.AutoSize = true;
        this.radioButton7.Checked = true;
        this.radioButton7.Location = new System.Drawing.Point(7, 20);
        this.radioButton7.Margin = new System.Windows.Forms.Padding(4);
        this.radioButton7.Name = "radioButton7";
        this.radioButton7.Size = new System.Drawing.Size(92, 17);
        this.radioButton7.TabIndex = 2;
        this.radioButton7.TabStop = true;
        this.radioButton7.Text = "Улица любая";
        this.radioButton7.UseVisualStyleBackColor = true;
        this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
        // 
        // groupBox5
        // 
        this.groupBox5.Controls.Add(this.textBox1);
        this.groupBox5.Location = new System.Drawing.Point(10, 135);
        this.groupBox5.Name = "groupBox5";
        this.groupBox5.Size = new System.Drawing.Size(269, 53);
        this.groupBox5.TabIndex = 4;
        this.groupBox5.TabStop = false;
        this.groupBox5.Text = "ФИО";
        // 
        // textBox1
        // 
        this.textBox1.Location = new System.Drawing.Point(7, 22);
        this.textBox1.Margin = new System.Windows.Forms.Padding(4);
        this.textBox1.Name = "textBox1";
        this.textBox1.Size = new System.Drawing.Size(256, 20);
        this.textBox1.TabIndex = 1;
        // 
        // groupBox11
        // 
        this.groupBox11.Controls.Add(this.numericUpDown5);
        this.groupBox11.Controls.Add(this.label9);
        this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox11.Location = new System.Drawing.Point(10, 85);
        this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox11.Name = "groupBox11";
        this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox11.Size = new System.Drawing.Size(132, 48);
        this.groupBox11.TabIndex = 15;
        this.groupBox11.TabStop = false;
        this.groupBox11.Text = "Сальдо н";
        // 
        // numericUpDown5
        // 
        this.numericUpDown5.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown5.Location = new System.Drawing.Point(38, 18);
        this.numericUpDown5.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown5.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown5.Name = "numericUpDown5";
        this.numericUpDown5.Size = new System.Drawing.Size(87, 20);
        this.numericUpDown5.TabIndex = 4;
        // 
        // label9
        // 
        this.label9.AutoSize = true;
        this.label9.Location = new System.Drawing.Point(7, 20);
        this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label9.Name = "label9";
        this.label9.Size = new System.Drawing.Size(22, 13);
        this.label9.TabIndex = 3;
        this.label9.Text = "От";
        // 
        // groupBox3
        // 
        this.groupBox3.Controls.Add(this.radioButton5);
        this.groupBox3.Controls.Add(this.comboBox1);
        this.groupBox3.Controls.Add(this.radioButton6);
        this.groupBox3.Location = new System.Drawing.Point(10, 297);
        this.groupBox3.Name = "groupBox3";
        this.groupBox3.Size = new System.Drawing.Size(269, 53);
        this.groupBox3.TabIndex = 2;
        this.groupBox3.TabStop = false;
        this.groupBox3.Text = "Выберите обсл. организацию";
        // 
        // radioButton5
        // 
        this.radioButton5.AutoSize = true;
        this.radioButton5.Location = new System.Drawing.Point(55, 22);
        this.radioButton5.Name = "radioButton5";
        this.radioButton5.Size = new System.Drawing.Size(55, 17);
        this.radioButton5.TabIndex = 13;
        this.radioButton5.TabStop = true;
        this.radioButton5.Text = "Выбр.";
        this.radioButton5.UseVisualStyleBackColor = true;
        this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
        // 
        // comboBox1
        // 
        this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBox1.Enabled = false;
        this.comboBox1.FormattingEnabled = true;
        this.comboBox1.Location = new System.Drawing.Point(127, 21);
        this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox1.MaxDropDownItems = 12;
        this.comboBox1.Name = "comboBox1";
        this.comboBox1.Size = new System.Drawing.Size(135, 20);
        this.comboBox1.TabIndex = 12;
        // 
        // radioButton6
        // 
        this.radioButton6.AutoSize = true;
        this.radioButton6.Checked = true;
        this.radioButton6.Location = new System.Drawing.Point(7, 22);
        this.radioButton6.Name = "radioButton6";
        this.radioButton6.Size = new System.Drawing.Size(42, 17);
        this.radioButton6.TabIndex = 0;
        this.radioButton6.TabStop = true;
        this.radioButton6.Text = "Все";
        this.radioButton6.UseVisualStyleBackColor = true;
        this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.label1.Location = new System.Drawing.Point(7, 9);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(138, 17);
        this.label1.TabIndex = 0;
        this.label1.Text = "Фильтры поиска:";
        // 
        // splitContainer2
        // 
        this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
        this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
        this.splitContainer2.Location = new System.Drawing.Point(0, 0);
        this.splitContainer2.Name = "splitContainer2";
        // 
        // splitContainer2.Panel1
        // 
        this.splitContainer2.Panel1.AutoScroll = true;
        this.splitContainer2.Panel1.Controls.Add(this.selLSBindingNavigator);
        this.splitContainer2.Panel1.Controls.Add(this.groupBox6);
        this.splitContainer2.Panel1.Controls.Add(this.label2);
        // 
        // splitContainer2.Panel2
        // 
        this.splitContainer2.Panel2.AutoScroll = true;
        this.splitContainer2.Panel2.Controls.Add(this.groupBox8);
        this.splitContainer2.Panel2.Controls.Add(this.label11);
        this.splitContainer2.Panel2.Controls.Add(this.groupBox7);
        this.splitContainer2.Panel2.Controls.Add(this.richTextBox1);
        this.splitContainer2.Size = new System.Drawing.Size(567, 565);
        this.splitContainer2.SplitterDistance = 249;
        this.splitContainer2.TabIndex = 0;
        // 
        // selLSBindingNavigator
        // 
        this.selLSBindingNavigator.AddNewItem = null;
        this.selLSBindingNavigator.BindingSource = this.selLSBindingSource;
        this.selLSBindingNavigator.CountItem = this.bindingNavigatorCountItem;
        this.selLSBindingNavigator.CountItemFormat = "из {0}";
        this.selLSBindingNavigator.DeleteItem = null;
        this.selLSBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
        this.selLSBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.selLSBindingNavigatorSaveItem});
        this.selLSBindingNavigator.Location = new System.Drawing.Point(7, 32);
        this.selLSBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
        this.selLSBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
        this.selLSBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
        this.selLSBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
        this.selLSBindingNavigator.Name = "selLSBindingNavigator";
        this.selLSBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
        this.selLSBindingNavigator.Size = new System.Drawing.Size(233, 27);
        this.selLSBindingNavigator.TabIndex = 3;
        this.selLSBindingNavigator.Text = "bindingNavigator1";
        // 
        // selLSBindingSource
        // 
        this.selLSBindingSource.DataMember = "selLS";
        this.selLSBindingSource.DataSource = this.archiveDataSet;
        // 
        // archiveDataSet
        // 
        this.archiveDataSet.DataSetName = "archiveDataSet";
        this.archiveDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
        // 
        // bindingNavigatorCountItem
        // 
        this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
        this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 24);
        this.bindingNavigatorCountItem.Text = "из {0}";
        this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
        // 
        // bindingNavigatorMoveFirstItem
        // 
        this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
        this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
        this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 24);
        this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
        // 
        // bindingNavigatorMovePreviousItem
        // 
        this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
        this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
        this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 24);
        this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
        // 
        // bindingNavigatorSeparator
        // 
        this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
        this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
        // 
        // bindingNavigatorPositionItem
        // 
        this.bindingNavigatorPositionItem.AccessibleName = "Положение";
        this.bindingNavigatorPositionItem.AutoSize = false;
        this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
        this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
        this.bindingNavigatorPositionItem.Text = "0";
        this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
        // 
        // bindingNavigatorSeparator1
        // 
        this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
        this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
        // 
        // bindingNavigatorMoveNextItem
        // 
        this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
        this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
        this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 24);
        this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
        // 
        // bindingNavigatorMoveLastItem
        // 
        this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
        this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
        this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 24);
        this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
        // 
        // bindingNavigatorSeparator2
        // 
        this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
        this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
        // 
        // selLSBindingNavigatorSaveItem
        // 
        this.selLSBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.selLSBindingNavigatorSaveItem.Enabled = false;
        this.selLSBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("selLSBindingNavigatorSaveItem.Image")));
        this.selLSBindingNavigatorSaveItem.Name = "selLSBindingNavigatorSaveItem";
        this.selLSBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 24);
        this.selLSBindingNavigatorSaveItem.Text = "Сохранить данные";
        // 
        // groupBox6
        // 
        this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                    | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox6.Controls.Add(this.selLSDataGridView);
        this.groupBox6.Location = new System.Drawing.Point(7, 62);
        this.groupBox6.Name = "groupBox6";
        this.groupBox6.Size = new System.Drawing.Size(235, 496);
        this.groupBox6.TabIndex = 4;
        this.groupBox6.TabStop = false;
        this.groupBox6.Text = "Найдено";
        // 
        // selLSDataGridView
        // 
        this.selLSDataGridView.AllowUserToAddRows = false;
        this.selLSDataGridView.AllowUserToDeleteRows = false;
        this.selLSDataGridView.AllowUserToOrderColumns = true;
        this.selLSDataGridView.AllowUserToResizeRows = false;
        this.selLSDataGridView.AutoGenerateColumns = false;
        this.selLSDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
        this.selLSDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
        this.selLSDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.selLSDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.LS,
            this.SAL1W,
            this.SAL2W,
            this.ITGNW,
            this.spZEU_NAIM,
            this.spUL_NAIM,
            this.DOM,
            this.DOML,
            this.DOMP,
            this.KV,
            this.KVL,
            this.PEN,
            this.NZEU,
            this.OPLATA_DO,
            this.DOLG_POSLE_OPLATY,
            this.fIODataGridViewTextBoxColumn,
            this.dOMDataGridViewTextBoxColumn,
            this.dOMLDataGridViewTextBoxColumn,
            this.dOMPDataGridViewTextBoxColumn,
            this.kVDataGridViewTextBoxColumn,
            this.kVLDataGridViewTextBoxColumn,
            this.lSDataGridViewTextBoxColumn,
            this.nZEUDataGridViewTextBoxColumn,
            this.uLDataGridViewTextBoxColumn,
            this.sAL2WDataGridViewTextBoxColumn,
            this.iTGNWDataGridViewTextBoxColumn,
            this.sAL1WDataGridViewTextBoxColumn,
            this.oPLATADODataGridViewTextBoxColumn,
            this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn,
            this.iNSDATEDataGridViewTextBoxColumn,
            this.cOMMENTDataGridViewTextBoxColumn,
            this.lSXDataGridViewTextBoxColumn,
            this.pENDataGridViewTextBoxColumn,
            this.spULNAIMDataGridViewTextBoxColumn,
            this.spZEUNAIMDataGridViewTextBoxColumn,
            this.streetDataGridViewTextBoxColumn,
            this.companyDataGridViewTextBoxColumn});
        this.selLSDataGridView.DataSource = this.selLSBindingSource;
        this.selLSDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
        this.selLSDataGridView.Location = new System.Drawing.Point(3, 16);
        this.selLSDataGridView.Name = "selLSDataGridView";
        this.selLSDataGridView.RowTemplate.Height = 24;
        this.selLSDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.selLSDataGridView.Size = new System.Drawing.Size(229, 477);
        this.selLSDataGridView.TabIndex = 0;
        // 
        // Column1
        // 
        this.Column1.DataPropertyName = "FIO";
        this.Column1.HeaderText = "ФИО";
        this.Column1.Name = "Column1";
        this.Column1.ReadOnly = true;
        this.Column1.Width = 55;
        // 
        // LS
        // 
        this.LS.DataPropertyName = "LS";
        this.LS.HeaderText = "Лиц.Сч.";
        this.LS.Name = "LS";
        this.LS.ReadOnly = true;
        this.LS.Width = 72;
        // 
        // SAL1W
        // 
        this.SAL1W.DataPropertyName = "SAL1W";
        this.SAL1W.HeaderText = "Сальдо Н.";
        this.SAL1W.Name = "SAL1W";
        this.SAL1W.ReadOnly = true;
        this.SAL1W.Width = 78;
        // 
        // SAL2W
        // 
        this.SAL2W.DataPropertyName = "SAL2W";
        this.SAL2W.HeaderText = "Сальдо К.";
        this.SAL2W.Name = "SAL2W";
        this.SAL2W.ReadOnly = true;
        this.SAL2W.Width = 78;
        // 
        // ITGNW
        // 
        this.ITGNW.DataPropertyName = "ITGNW";
        this.ITGNW.HeaderText = "Начисл,р.";
        this.ITGNW.Name = "ITGNW";
        this.ITGNW.ReadOnly = true;
        this.ITGNW.Width = 82;
        // 
        // spZEU_NAIM
        // 
        this.spZEU_NAIM.DataPropertyName = "Company";
        this.spZEU_NAIM.HeaderText = "Компания";
        this.spZEU_NAIM.Name = "spZEU_NAIM";
        this.spZEU_NAIM.ReadOnly = true;
        this.spZEU_NAIM.Width = 81;
        // 
        // spUL_NAIM
        // 
        this.spUL_NAIM.DataPropertyName = "Street";
        this.spUL_NAIM.HeaderText = "Улица";
        this.spUL_NAIM.Name = "spUL_NAIM";
        this.spUL_NAIM.ReadOnly = true;
        this.spUL_NAIM.Width = 63;
        // 
        // DOM
        // 
        this.DOM.DataPropertyName = "DOM";
        this.DOM.HeaderText = "№ дом";
        this.DOM.Name = "DOM";
        this.DOM.ReadOnly = true;
        this.DOM.Width = 62;
        // 
        // DOML
        // 
        this.DOML.DataPropertyName = "DOML";
        this.DOML.HeaderText = "Корпус";
        this.DOML.Name = "DOML";
        this.DOML.ReadOnly = true;
        this.DOML.Width = 67;
        // 
        // DOMP
        // 
        this.DOMP.DataPropertyName = "DOMP";
        this.DOMP.HeaderText = "Пристройка";
        this.DOMP.Name = "DOMP";
        this.DOMP.ReadOnly = true;
        this.DOMP.Visible = false;
        this.DOMP.Width = 92;
        // 
        // KV
        // 
        this.KV.DataPropertyName = "KV";
        this.KV.HeaderText = "Кв.";
        this.KV.Name = "KV";
        this.KV.ReadOnly = true;
        this.KV.Width = 49;
        // 
        // KVL
        // 
        this.KVL.DataPropertyName = "KVL";
        this.KVL.HeaderText = "Кв.лит";
        this.KVL.Name = "KVL";
        this.KVL.ReadOnly = true;
        this.KVL.Width = 67;
        // 
        // PEN
        // 
        this.PEN.DataPropertyName = "PEN";
        this.PEN.HeaderText = "Пеня,р.";
        this.PEN.Name = "PEN";
        this.PEN.ReadOnly = true;
        this.PEN.Width = 71;
        // 
        // NZEU
        // 
        this.NZEU.DataPropertyName = "NZEU";
        this.NZEU.HeaderText = "№ЖЭУ";
        this.NZEU.Name = "NZEU";
        this.NZEU.ReadOnly = true;
        this.NZEU.Width = 69;
        // 
        // OPLATA_DO
        // 
        this.OPLATA_DO.DataPropertyName = "OPLATA_DO";
        this.OPLATA_DO.HeaderText = "Оплатить до";
        this.OPLATA_DO.Name = "OPLATA_DO";
        this.OPLATA_DO.ReadOnly = true;
        this.OPLATA_DO.Width = 90;
        // 
        // DOLG_POSLE_OPLATY
        // 
        this.DOLG_POSLE_OPLATY.DataPropertyName = "DOLG_POSLE_OPLATY";
        this.DOLG_POSLE_OPLATY.HeaderText = "Долг не больше,р.";
        this.DOLG_POSLE_OPLATY.Name = "DOLG_POSLE_OPLATY";
        this.DOLG_POSLE_OPLATY.ReadOnly = true;
        this.DOLG_POSLE_OPLATY.Width = 116;
        // 
        // fIODataGridViewTextBoxColumn
        // 
        this.fIODataGridViewTextBoxColumn.DataPropertyName = "FIO";
        this.fIODataGridViewTextBoxColumn.HeaderText = "FIO";
        this.fIODataGridViewTextBoxColumn.Name = "fIODataGridViewTextBoxColumn";
        this.fIODataGridViewTextBoxColumn.Visible = false;
        this.fIODataGridViewTextBoxColumn.Width = 50;
        // 
        // dOMDataGridViewTextBoxColumn
        // 
        this.dOMDataGridViewTextBoxColumn.DataPropertyName = "DOM";
        this.dOMDataGridViewTextBoxColumn.HeaderText = "DOM";
        this.dOMDataGridViewTextBoxColumn.Name = "dOMDataGridViewTextBoxColumn";
        this.dOMDataGridViewTextBoxColumn.Visible = false;
        this.dOMDataGridViewTextBoxColumn.Width = 55;
        // 
        // dOMLDataGridViewTextBoxColumn
        // 
        this.dOMLDataGridViewTextBoxColumn.DataPropertyName = "DOML";
        this.dOMLDataGridViewTextBoxColumn.HeaderText = "DOML";
        this.dOMLDataGridViewTextBoxColumn.Name = "dOMLDataGridViewTextBoxColumn";
        this.dOMLDataGridViewTextBoxColumn.Visible = false;
        this.dOMLDataGridViewTextBoxColumn.Width = 60;
        // 
        // dOMPDataGridViewTextBoxColumn
        // 
        this.dOMPDataGridViewTextBoxColumn.DataPropertyName = "DOMP";
        this.dOMPDataGridViewTextBoxColumn.HeaderText = "DOMP";
        this.dOMPDataGridViewTextBoxColumn.Name = "dOMPDataGridViewTextBoxColumn";
        this.dOMPDataGridViewTextBoxColumn.Visible = false;
        this.dOMPDataGridViewTextBoxColumn.Width = 61;
        // 
        // kVDataGridViewTextBoxColumn
        // 
        this.kVDataGridViewTextBoxColumn.DataPropertyName = "KV";
        this.kVDataGridViewTextBoxColumn.HeaderText = "KV";
        this.kVDataGridViewTextBoxColumn.Name = "kVDataGridViewTextBoxColumn";
        this.kVDataGridViewTextBoxColumn.Visible = false;
        this.kVDataGridViewTextBoxColumn.Width = 44;
        // 
        // kVLDataGridViewTextBoxColumn
        // 
        this.kVLDataGridViewTextBoxColumn.DataPropertyName = "KVL";
        this.kVLDataGridViewTextBoxColumn.HeaderText = "KVL";
        this.kVLDataGridViewTextBoxColumn.Name = "kVLDataGridViewTextBoxColumn";
        this.kVLDataGridViewTextBoxColumn.Visible = false;
        this.kVLDataGridViewTextBoxColumn.Width = 49;
        // 
        // lSDataGridViewTextBoxColumn
        // 
        this.lSDataGridViewTextBoxColumn.DataPropertyName = "LS";
        this.lSDataGridViewTextBoxColumn.HeaderText = "LS";
        this.lSDataGridViewTextBoxColumn.Name = "lSDataGridViewTextBoxColumn";
        this.lSDataGridViewTextBoxColumn.Visible = false;
        this.lSDataGridViewTextBoxColumn.Width = 43;
        // 
        // nZEUDataGridViewTextBoxColumn
        // 
        this.nZEUDataGridViewTextBoxColumn.DataPropertyName = "NZEU";
        this.nZEUDataGridViewTextBoxColumn.HeaderText = "NZEU";
        this.nZEUDataGridViewTextBoxColumn.Name = "nZEUDataGridViewTextBoxColumn";
        this.nZEUDataGridViewTextBoxColumn.Visible = false;
        this.nZEUDataGridViewTextBoxColumn.Width = 58;
        // 
        // uLDataGridViewTextBoxColumn
        // 
        this.uLDataGridViewTextBoxColumn.DataPropertyName = "UL";
        this.uLDataGridViewTextBoxColumn.HeaderText = "UL";
        this.uLDataGridViewTextBoxColumn.Name = "uLDataGridViewTextBoxColumn";
        this.uLDataGridViewTextBoxColumn.Visible = false;
        this.uLDataGridViewTextBoxColumn.Width = 44;
        // 
        // sAL2WDataGridViewTextBoxColumn
        // 
        this.sAL2WDataGridViewTextBoxColumn.DataPropertyName = "SAL2W";
        this.sAL2WDataGridViewTextBoxColumn.HeaderText = "SAL2W";
        this.sAL2WDataGridViewTextBoxColumn.Name = "sAL2WDataGridViewTextBoxColumn";
        this.sAL2WDataGridViewTextBoxColumn.ReadOnly = true;
        this.sAL2WDataGridViewTextBoxColumn.Visible = false;
        this.sAL2WDataGridViewTextBoxColumn.Width = 66;
        // 
        // iTGNWDataGridViewTextBoxColumn
        // 
        this.iTGNWDataGridViewTextBoxColumn.DataPropertyName = "ITGNW";
        this.iTGNWDataGridViewTextBoxColumn.HeaderText = "ITGNW";
        this.iTGNWDataGridViewTextBoxColumn.Name = "iTGNWDataGridViewTextBoxColumn";
        this.iTGNWDataGridViewTextBoxColumn.Visible = false;
        this.iTGNWDataGridViewTextBoxColumn.Width = 66;
        // 
        // sAL1WDataGridViewTextBoxColumn
        // 
        this.sAL1WDataGridViewTextBoxColumn.DataPropertyName = "SAL1W";
        this.sAL1WDataGridViewTextBoxColumn.HeaderText = "SAL1W";
        this.sAL1WDataGridViewTextBoxColumn.Name = "sAL1WDataGridViewTextBoxColumn";
        this.sAL1WDataGridViewTextBoxColumn.ReadOnly = true;
        this.sAL1WDataGridViewTextBoxColumn.Visible = false;
        this.sAL1WDataGridViewTextBoxColumn.Width = 66;
        // 
        // oPLATADODataGridViewTextBoxColumn
        // 
        this.oPLATADODataGridViewTextBoxColumn.DataPropertyName = "OPLATA_DO";
        this.oPLATADODataGridViewTextBoxColumn.HeaderText = "OPLATA_DO";
        this.oPLATADODataGridViewTextBoxColumn.Name = "oPLATADODataGridViewTextBoxColumn";
        this.oPLATADODataGridViewTextBoxColumn.Visible = false;
        this.oPLATADODataGridViewTextBoxColumn.Width = 92;
        // 
        // dOLGPOSLEOPLATYDataGridViewTextBoxColumn
        // 
        this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn.DataPropertyName = "DOLG_POSLE_OPLATY";
        this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn.HeaderText = "DOLG_POSLE_OPLATY";
        this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn.Name = "dOLGPOSLEOPLATYDataGridViewTextBoxColumn";
        this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn.Visible = false;
        this.dOLGPOSLEOPLATYDataGridViewTextBoxColumn.Width = 140;
        // 
        // iNSDATEDataGridViewTextBoxColumn
        // 
        this.iNSDATEDataGridViewTextBoxColumn.DataPropertyName = "INS_DATE";
        this.iNSDATEDataGridViewTextBoxColumn.HeaderText = "INS_DATE";
        this.iNSDATEDataGridViewTextBoxColumn.Name = "iNSDATEDataGridViewTextBoxColumn";
        this.iNSDATEDataGridViewTextBoxColumn.Visible = false;
        this.iNSDATEDataGridViewTextBoxColumn.Width = 81;
        // 
        // cOMMENTDataGridViewTextBoxColumn
        // 
        this.cOMMENTDataGridViewTextBoxColumn.DataPropertyName = "COMMENT";
        this.cOMMENTDataGridViewTextBoxColumn.HeaderText = "COMMENT";
        this.cOMMENTDataGridViewTextBoxColumn.Name = "cOMMENTDataGridViewTextBoxColumn";
        this.cOMMENTDataGridViewTextBoxColumn.Visible = false;
        this.cOMMENTDataGridViewTextBoxColumn.Width = 82;
        // 
        // lSXDataGridViewTextBoxColumn
        // 
        this.lSXDataGridViewTextBoxColumn.DataPropertyName = "LSX";
        this.lSXDataGridViewTextBoxColumn.HeaderText = "LSX";
        this.lSXDataGridViewTextBoxColumn.Name = "lSXDataGridViewTextBoxColumn";
        this.lSXDataGridViewTextBoxColumn.Visible = false;
        this.lSXDataGridViewTextBoxColumn.Width = 49;
        // 
        // pENDataGridViewTextBoxColumn
        // 
        this.pENDataGridViewTextBoxColumn.DataPropertyName = "PEN";
        this.pENDataGridViewTextBoxColumn.HeaderText = "PEN";
        this.pENDataGridViewTextBoxColumn.Name = "pENDataGridViewTextBoxColumn";
        this.pENDataGridViewTextBoxColumn.Visible = false;
        this.pENDataGridViewTextBoxColumn.Width = 51;
        // 
        // spULNAIMDataGridViewTextBoxColumn
        // 
        this.spULNAIMDataGridViewTextBoxColumn.DataPropertyName = "spUL_NAIM";
        this.spULNAIMDataGridViewTextBoxColumn.HeaderText = "spUL_NAIM";
        this.spULNAIMDataGridViewTextBoxColumn.Name = "spULNAIMDataGridViewTextBoxColumn";
        this.spULNAIMDataGridViewTextBoxColumn.Visible = false;
        this.spULNAIMDataGridViewTextBoxColumn.Width = 87;
        // 
        // spZEUNAIMDataGridViewTextBoxColumn
        // 
        this.spZEUNAIMDataGridViewTextBoxColumn.DataPropertyName = "spZEU_NAIM";
        this.spZEUNAIMDataGridViewTextBoxColumn.HeaderText = "spZEU_NAIM";
        this.spZEUNAIMDataGridViewTextBoxColumn.Name = "spZEUNAIMDataGridViewTextBoxColumn";
        this.spZEUNAIMDataGridViewTextBoxColumn.Visible = false;
        this.spZEUNAIMDataGridViewTextBoxColumn.Width = 94;
        // 
        // streetDataGridViewTextBoxColumn
        // 
        this.streetDataGridViewTextBoxColumn.DataPropertyName = "Street";
        this.streetDataGridViewTextBoxColumn.HeaderText = "Street";
        this.streetDataGridViewTextBoxColumn.Name = "streetDataGridViewTextBoxColumn";
        this.streetDataGridViewTextBoxColumn.Visible = false;
        this.streetDataGridViewTextBoxColumn.Width = 62;
        // 
        // companyDataGridViewTextBoxColumn
        // 
        this.companyDataGridViewTextBoxColumn.DataPropertyName = "Company";
        this.companyDataGridViewTextBoxColumn.HeaderText = "Company";
        this.companyDataGridViewTextBoxColumn.Name = "companyDataGridViewTextBoxColumn";
        this.companyDataGridViewTextBoxColumn.Visible = false;
        this.companyDataGridViewTextBoxColumn.Width = 77;
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.label2.Location = new System.Drawing.Point(10, 5);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(153, 17);
        this.label2.TabIndex = 3;
        this.label2.Text = "Результаты поиска";
        // 
        // groupBox8
        // 
        this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox8.Controls.Add(this.maskedTextBox2);
        this.groupBox8.Controls.Add(this.label15);
        this.groupBox8.Controls.Add(this.button2);
        this.groupBox8.Controls.Add(this.label12);
        this.groupBox8.Controls.Add(this.dateTimePicker1);
        this.groupBox8.Controls.Add(this.textBox2);
        this.groupBox8.Controls.Add(this.richTextBox2);
        this.groupBox8.Controls.Add(label13);
        this.groupBox8.Controls.Add(label14);
        this.groupBox8.Location = new System.Drawing.Point(4, 254);
        this.groupBox8.Name = "groupBox8";
        this.groupBox8.Size = new System.Drawing.Size(306, 230);
        this.groupBox8.TabIndex = 5;
        this.groupBox8.TabStop = false;
        this.groupBox8.Text = "Установить\\изменить комментарий";
        // 
        // maskedTextBox2
        // 
        this.maskedTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.maskedTextBox2.BeepOnError = true;
        this.maskedTextBox2.Location = new System.Drawing.Point(209, 162);
        this.maskedTextBox2.Margin = new System.Windows.Forms.Padding(4);
        this.maskedTextBox2.Mask = "000000000000000000";
        this.maskedTextBox2.Name = "maskedTextBox2";
        this.maskedTextBox2.PromptChar = '.';
        this.maskedTextBox2.Size = new System.Drawing.Size(89, 20);
        this.maskedTextBox2.TabIndex = 12;
        this.maskedTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // label15
        // 
        this.label15.AutoSize = true;
        this.label15.Location = new System.Drawing.Point(9, 165);
        this.label15.Name = "label15";
        this.label15.Size = new System.Drawing.Size(167, 13);
        this.label15.TabIndex = 11;
        this.label15.Text = "Долг после оплаты, не более:*";
        // 
        // button2
        // 
        this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.button2.Location = new System.Drawing.Point(12, 194);
        this.button2.Name = "button2";
        this.button2.Size = new System.Drawing.Size(287, 24);
        this.button2.TabIndex = 10;
        this.button2.Text = "Сохранить";
        this.button2.UseVisualStyleBackColor = true;
        this.button2.Click += new System.EventHandler(this.button2_Click);
        // 
        // label12
        // 
        this.label12.AutoSize = true;
        this.label12.Location = new System.Drawing.Point(9, 135);
        this.label12.Name = "label12";
        this.label12.Size = new System.Drawing.Size(51, 13);
        this.label12.TabIndex = 9;
        this.label12.Text = "Выбрать";
        // 
        // dateTimePicker1
        // 
        this.dateTimePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.dateTimePicker1.Location = new System.Drawing.Point(110, 130);
        this.dateTimePicker1.Name = "dateTimePicker1";
        this.dateTimePicker1.Size = new System.Drawing.Size(189, 20);
        this.dateTimePicker1.TabIndex = 8;
        this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
        // 
        // textBox2
        // 
        this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.textBox2.Location = new System.Drawing.Point(110, 96);
        this.textBox2.Name = "textBox2";
        this.textBox2.ReadOnly = true;
        this.textBox2.Size = new System.Drawing.Size(189, 20);
        this.textBox2.TabIndex = 7;
        // 
        // richTextBox2
        // 
        this.richTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.richTextBox2.Location = new System.Drawing.Point(12, 39);
        this.richTextBox2.Name = "richTextBox2";
        this.richTextBox2.Size = new System.Drawing.Size(287, 57);
        this.richTextBox2.TabIndex = 6;
        this.richTextBox2.Text = "";
        // 
        // label11
        // 
        this.label11.AutoSize = true;
        this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.label11.Location = new System.Drawing.Point(3, 5);
        this.label11.Name = "label11";
        this.label11.Size = new System.Drawing.Size(209, 17);
        this.label11.TabIndex = 4;
        this.label11.Text = "Просмотр/редактирование";
        // 
        // groupBox7
        // 
        this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox7.Controls.Add(this.button3);
        this.groupBox7.Controls.Add(iNS_DATELabel);
        this.groupBox7.Controls.Add(this.iNS_DATETextBox);
        this.groupBox7.Controls.Add(oPLATA_DOLabel);
        this.groupBox7.Controls.Add(this.oPLATA_DOTextBox);
        this.groupBox7.Controls.Add(cOMMENTLabel);
        this.groupBox7.Controls.Add(this.cOMMENTRichTextBox);
        this.groupBox7.Controls.Add(fIOLabel);
        this.groupBox7.Controls.Add(this.fIOLabel1);
        this.groupBox7.Location = new System.Drawing.Point(4, 28);
        this.groupBox7.Name = "groupBox7";
        this.groupBox7.Size = new System.Drawing.Size(306, 225);
        this.groupBox7.TabIndex = 1;
        this.groupBox7.TabStop = false;
        this.groupBox7.Text = "Установленный комментарий";
        // 
        // button3
        // 
        this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.button3.Location = new System.Drawing.Point(12, 188);
        this.button3.Name = "button3";
        this.button3.Size = new System.Drawing.Size(287, 24);
        this.button3.TabIndex = 11;
        this.button3.Text = "Удалить комментарий";
        this.button3.UseVisualStyleBackColor = true;
        this.button3.Click += new System.EventHandler(this.button3_Click);
        // 
        // iNS_DATETextBox
        // 
        this.iNS_DATETextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.iNS_DATETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.selLSBindingSource, "INS_DATE", true));
        this.iNS_DATETextBox.Location = new System.Drawing.Point(122, 149);
        this.iNS_DATETextBox.Name = "iNS_DATETextBox";
        this.iNS_DATETextBox.ReadOnly = true;
        this.iNS_DATETextBox.Size = new System.Drawing.Size(177, 20);
        this.iNS_DATETextBox.TabIndex = 7;
        // 
        // oPLATA_DOTextBox
        // 
        this.oPLATA_DOTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.oPLATA_DOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.selLSBindingSource, "OPLATA_DO", true));
        this.oPLATA_DOTextBox.Location = new System.Drawing.Point(122, 117);
        this.oPLATA_DOTextBox.Name = "oPLATA_DOTextBox";
        this.oPLATA_DOTextBox.ReadOnly = true;
        this.oPLATA_DOTextBox.Size = new System.Drawing.Size(177, 20);
        this.oPLATA_DOTextBox.TabIndex = 5;
        // 
        // cOMMENTRichTextBox
        // 
        this.cOMMENTRichTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.cOMMENTRichTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.selLSBindingSource, "COMMENT", true));
        this.cOMMENTRichTextBox.Location = new System.Drawing.Point(12, 57);
        this.cOMMENTRichTextBox.Name = "cOMMENTRichTextBox";
        this.cOMMENTRichTextBox.ReadOnly = true;
        this.cOMMENTRichTextBox.Size = new System.Drawing.Size(287, 56);
        this.cOMMENTRichTextBox.TabIndex = 3;
        this.cOMMENTRichTextBox.Text = "";
        // 
        // fIOLabel1
        // 
        this.fIOLabel1.AutoSize = true;
        this.fIOLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.selLSBindingSource, "FIO", true));
        this.fIOLabel1.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.fIOLabel1.Location = new System.Drawing.Point(55, 19);
        this.fIOLabel1.Name = "fIOLabel1";
        this.fIOLabel1.Size = new System.Drawing.Size(0, 13);
        this.fIOLabel1.TabIndex = 1;
        // 
        // richTextBox1
        // 
        this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.richTextBox1.Location = new System.Drawing.Point(0, 517);
        this.richTextBox1.Name = "richTextBox1";
        this.richTextBox1.ReadOnly = true;
        this.richTextBox1.Size = new System.Drawing.Size(310, 44);
        this.richTextBox1.TabIndex = 0;
        this.richTextBox1.Text = "";
        // 
        // selLSTableAdapter
        // 
        this.selLSTableAdapter.ClearBeforeFill = true;
        // 
        // tableAdapterManager
        // 
        this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
        this.tableAdapterManager.Connection = null;
        this.tableAdapterManager.UpdateOrder = souz.archiveDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
        // 
        // timer1
        // 
        this.timer1.Interval = 15000;
        this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
        // 
        // FMain
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.AutoScroll = true;
        this.ClientSize = new System.Drawing.Size(865, 630);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.statusStrip1);
        this.Controls.Add(this.menuStrip1);
        this.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MainMenuStrip = this.menuStrip1;
        this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
        this.Name = "FMain";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Работа с должниками";
        this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        this.Load += new System.EventHandler(this.FMain_Load);
        this.menuStrip1.ResumeLayout(false);
        this.menuStrip1.PerformLayout();
        this.statusStrip1.ResumeLayout(false);
        this.statusStrip1.PerformLayout();
        this.groupBox1.ResumeLayout(false);
        this.splitContainer1.Panel1.ResumeLayout(false);
        this.splitContainer1.Panel1.PerformLayout();
        this.splitContainer1.Panel2.ResumeLayout(false);
        this.splitContainer1.ResumeLayout(false);
        this.groupBox10.ResumeLayout(false);
        this.groupBox10.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
        this.groupBox13.ResumeLayout(false);
        this.groupBox13.PerformLayout();
        this.groupBox2.ResumeLayout(false);
        this.groupBox2.PerformLayout();
        this.groupBox4.ResumeLayout(false);
        this.groupBox4.PerformLayout();
        this.groupBox12.ResumeLayout(false);
        this.groupBox12.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
        this.groupBox9.ResumeLayout(false);
        this.groupBox9.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
        this.groupBox5.ResumeLayout(false);
        this.groupBox5.PerformLayout();
        this.groupBox11.ResumeLayout(false);
        this.groupBox11.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
        this.groupBox3.ResumeLayout(false);
        this.groupBox3.PerformLayout();
        this.splitContainer2.Panel1.ResumeLayout(false);
        this.splitContainer2.Panel1.PerformLayout();
        this.splitContainer2.Panel2.ResumeLayout(false);
        this.splitContainer2.Panel2.PerformLayout();
        this.splitContainer2.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.selLSBindingNavigator)).EndInit();
        this.selLSBindingNavigator.ResumeLayout(false);
        this.selLSBindingNavigator.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.selLSBindingSource)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.archiveDataSet)).EndInit();
        this.groupBox6.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.selLSDataGridView)).EndInit();
        this.groupBox8.ResumeLayout(false);
        this.groupBox8.PerformLayout();
        this.groupBox7.ResumeLayout(false);
        this.groupBox7.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ToolStripMenuItem начатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem начатьРаботуToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox7;
        private archiveDataSet archiveDataSet;
        private System.Windows.Forms.BindingSource selLSBindingSource;
        private archiveDataSetTableAdapters.selLSTableAdapter selLSTableAdapter;
        private archiveDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator selLSBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton selLSBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView selLSDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.Label fIOLabel1;
        private System.Windows.Forms.RichTextBox cOMMENTRichTextBox;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.TextBox iNS_DATETextBox;
        private System.Windows.Forms.TextBox oPLATA_DOTextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ToolStripMenuItem экспортВКвитанцииToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ToolStripMenuItem экспорт2ToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn LS;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAL1W;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAL2W;
        private System.Windows.Forms.DataGridViewTextBoxColumn ITGNW;
        private System.Windows.Forms.DataGridViewTextBoxColumn spZEU_NAIM;
        private System.Windows.Forms.DataGridViewTextBoxColumn spUL_NAIM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOML;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOMP;
        private System.Windows.Forms.DataGridViewTextBoxColumn KV;
        private System.Windows.Forms.DataGridViewTextBoxColumn KVL;
        private System.Windows.Forms.DataGridViewTextBoxColumn PEN;
        private System.Windows.Forms.DataGridViewTextBoxColumn NZEU;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPLATA_DO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOLG_POSLE_OPLATY;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOMLDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOMPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kVDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kVLDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nZEUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uLDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sAL2WDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iTGNWDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sAL1WDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oPLATADODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOLGPOSLEOPLATYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNSDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMMENTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lSXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pENDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn spULNAIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn spZEUNAIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn streetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyDataGridViewTextBoxColumn;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Timer timer1;
    }
}

