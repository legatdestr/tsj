﻿namespace souz {
    
    
    public partial class archiveDataSet {
        partial class selLSDataTable
            {
            }
    }
}

namespace souz.archiveDataSetTableAdapters {
    
    
    public partial class selLSTableAdapter {
    }
}
