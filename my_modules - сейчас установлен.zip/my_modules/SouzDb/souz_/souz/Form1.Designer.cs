﻿namespace souz
{
    partial class FMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
        this.components = new System.ComponentModel.Container();
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
        this.menuStrip1 = new System.Windows.Forms.MenuStrip();
        this.dataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.serviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.начатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.начатьРаботуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.statusStrip1 = new System.Windows.Forms.StatusStrip();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.splitContainer1 = new System.Windows.Forms.SplitContainer();
        this.button1 = new System.Windows.Forms.Button();
        this.groupBox13 = new System.Windows.Forms.GroupBox();
        this.comboBox3 = new System.Windows.Forms.ComboBox();
        this.label8 = new System.Windows.Forms.Label();
        this.groupBox2 = new System.Windows.Forms.GroupBox();
        this.radioButton3 = new System.Windows.Forms.RadioButton();
        this.radioButton2 = new System.Windows.Forms.RadioButton();
        this.radioButton1 = new System.Windows.Forms.RadioButton();
        this.groupBox10 = new System.Windows.Forms.GroupBox();
        this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
        this.label5 = new System.Windows.Forms.Label();
        this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
        this.label6 = new System.Windows.Forms.Label();
        this.groupBox4 = new System.Windows.Forms.GroupBox();
        this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
        this.groupBox12 = new System.Windows.Forms.GroupBox();
        this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
        this.label7 = new System.Windows.Forms.Label();
        this.groupBox9 = new System.Windows.Forms.GroupBox();
        this.label10 = new System.Windows.Forms.Label();
        this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
        this.label3 = new System.Windows.Forms.Label();
        this.label4 = new System.Windows.Forms.Label();
        this.textBox3 = new System.Windows.Forms.TextBox();
        this.comboBox2 = new System.Windows.Forms.ComboBox();
        this.radioButton4 = new System.Windows.Forms.RadioButton();
        this.radioButton7 = new System.Windows.Forms.RadioButton();
        this.groupBox5 = new System.Windows.Forms.GroupBox();
        this.textBox1 = new System.Windows.Forms.TextBox();
        this.groupBox11 = new System.Windows.Forms.GroupBox();
        this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
        this.label9 = new System.Windows.Forms.Label();
        this.groupBox3 = new System.Windows.Forms.GroupBox();
        this.radioButton5 = new System.Windows.Forms.RadioButton();
        this.comboBox1 = new System.Windows.Forms.ComboBox();
        this.radioButton6 = new System.Windows.Forms.RadioButton();
        this.label1 = new System.Windows.Forms.Label();
        this.splitContainer2 = new System.Windows.Forms.SplitContainer();
        this.groupBox6 = new System.Windows.Forms.GroupBox();
        this.selLSDataGridView = new System.Windows.Forms.DataGridView();
        this.ITGNW = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.PEN_S1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.SAL1W = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.SAL2W = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.label2 = new System.Windows.Forms.Label();
        this.label11 = new System.Windows.Forms.Label();
        this.groupBox7 = new System.Windows.Forms.GroupBox();
        this.fIOLabel1 = new System.Windows.Forms.Label();
        this.richTextBox1 = new System.Windows.Forms.RichTextBox();
        this.archiveDataSet = new souz.archiveDataSet();
        this.selLSBindingSource = new System.Windows.Forms.BindingSource(this.components);
        this.selLSTableAdapter = new souz.archiveDataSetTableAdapters.selLSTableAdapter();
        this.tableAdapterManager = new souz.archiveDataSetTableAdapters.TableAdapterManager();
        this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
        this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
        this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
        this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
        this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
        this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
        this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
        this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
        this.menuStrip1.SuspendLayout();
        this.groupBox1.SuspendLayout();
        this.splitContainer1.Panel1.SuspendLayout();
        this.splitContainer1.Panel2.SuspendLayout();
        this.splitContainer1.SuspendLayout();
        this.groupBox13.SuspendLayout();
        this.groupBox2.SuspendLayout();
        this.groupBox10.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
        this.groupBox4.SuspendLayout();
        this.groupBox12.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
        this.groupBox9.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
        this.groupBox5.SuspendLayout();
        this.groupBox11.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
        this.groupBox3.SuspendLayout();
        this.splitContainer2.Panel1.SuspendLayout();
        this.splitContainer2.Panel2.SuspendLayout();
        this.splitContainer2.SuspendLayout();
        this.groupBox6.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.selLSDataGridView)).BeginInit();
        this.groupBox7.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.archiveDataSet)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.selLSBindingSource)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
        this.bindingNavigator1.SuspendLayout();
        this.SuspendLayout();
        // 
        // menuStrip1
        // 
        this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataToolStripMenuItem,
            this.serviceToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.начатьToolStripMenuItem});
        this.menuStrip1.Location = new System.Drawing.Point(0, 0);
        this.menuStrip1.Name = "menuStrip1";
        this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
        this.menuStrip1.Size = new System.Drawing.Size(865, 28);
        this.menuStrip1.TabIndex = 0;
        this.menuStrip1.Text = "menuStrip1";
        // 
        // dataToolStripMenuItem
        // 
        this.dataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem});
        this.dataToolStripMenuItem.Name = "dataToolStripMenuItem";
        this.dataToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
        this.dataToolStripMenuItem.Text = "Данные";
        // 
        // loadToolStripMenuItem
        // 
        this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
        this.loadToolStripMenuItem.Size = new System.Drawing.Size(374, 24);
        this.loadToolStripMenuItem.Text = "Загрузить из общей базы/обновить архив";
        this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
        // 
        // serviceToolStripMenuItem
        // 
        this.serviceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem});
        this.serviceToolStripMenuItem.Name = "serviceToolStripMenuItem";
        this.serviceToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
        this.serviceToolStripMenuItem.Text = "Сервис";
        // 
        // settingsToolStripMenuItem
        // 
        this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
        this.settingsToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
        this.settingsToolStripMenuItem.Text = "Настройки";
        this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
        // 
        // helpToolStripMenuItem
        // 
        this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
        this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
        this.helpToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
        this.helpToolStripMenuItem.Text = "Справка";
        // 
        // оПрограммеToolStripMenuItem
        // 
        this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
        this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
        this.оПрограммеToolStripMenuItem.Text = "О программе";
        this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
        // 
        // начатьToolStripMenuItem
        // 
        this.начатьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.начатьРаботуToolStripMenuItem});
        this.начатьToolStripMenuItem.Name = "начатьToolStripMenuItem";
        this.начатьToolStripMenuItem.Size = new System.Drawing.Size(132, 24);
        this.начатьToolStripMenuItem.Text = "Дополнительно";
        // 
        // начатьРаботуToolStripMenuItem
        // 
        this.начатьРаботуToolStripMenuItem.Name = "начатьРаботуToolStripMenuItem";
        this.начатьРаботуToolStripMenuItem.Size = new System.Drawing.Size(260, 24);
        this.начатьРаботуToolStripMenuItem.Text = "Подключить справочники";
        this.начатьРаботуToolStripMenuItem.Click += new System.EventHandler(this.начатьРаботуToolStripMenuItem_Click);
        // 
        // statusStrip1
        // 
        this.statusStrip1.Location = new System.Drawing.Point(0, 608);
        this.statusStrip1.Name = "statusStrip1";
        this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 12, 0);
        this.statusStrip1.Size = new System.Drawing.Size(865, 22);
        this.statusStrip1.TabIndex = 1;
        this.statusStrip1.Text = "statusStrip1";
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.splitContainer1);
        this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
        this.groupBox1.Location = new System.Drawing.Point(0, 28);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(865, 580);
        this.groupBox1.TabIndex = 2;
        this.groupBox1.TabStop = false;
        // 
        // splitContainer1
        // 
        this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
        this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
        this.splitContainer1.Location = new System.Drawing.Point(3, 19);
        this.splitContainer1.Name = "splitContainer1";
        // 
        // splitContainer1.Panel1
        // 
        this.splitContainer1.Panel1.AutoScroll = true;
        this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control;
        this.splitContainer1.Panel1.Controls.Add(this.button1);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox13);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox10);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox4);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox12);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox9);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox5);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox11);
        this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
        this.splitContainer1.Panel1.Controls.Add(this.label1);
        // 
        // splitContainer1.Panel2
        // 
        this.splitContainer1.Panel2.AutoScroll = true;
        this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Window;
        this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
        this.splitContainer1.Size = new System.Drawing.Size(859, 558);
        this.splitContainer1.SplitterDistance = 288;
        this.splitContainer1.TabIndex = 0;
        // 
        // button1
        // 
        this.button1.Font = new System.Drawing.Font("Tahoma", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.button1.Location = new System.Drawing.Point(9, 508);
        this.button1.Name = "button1";
        this.button1.Size = new System.Drawing.Size(271, 24);
        this.button1.TabIndex = 18;
        this.button1.Text = "Поиск!";
        this.button1.UseVisualStyleBackColor = true;
        this.button1.Click += new System.EventHandler(this.button1_Click);
        // 
        // groupBox13
        // 
        this.groupBox13.Controls.Add(this.comboBox3);
        this.groupBox13.Controls.Add(this.label8);
        this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox13.Location = new System.Drawing.Point(10, 448);
        this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox13.Name = "groupBox13";
        this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox13.Size = new System.Drawing.Size(269, 48);
        this.groupBox13.TabIndex = 17;
        this.groupBox13.TabStop = false;
        this.groupBox13.Text = "Упорядочить";
        // 
        // comboBox3
        // 
        this.comboBox3.FormattingEnabled = true;
        this.comboBox3.Items.AddRange(new object[] {
            "Адрес (Улица и номер дома)",
            "НачислИтг(Долг)",
            "ФИО"});
        this.comboBox3.Location = new System.Drawing.Point(35, 19);
        this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox3.Name = "comboBox3";
        this.comboBox3.Size = new System.Drawing.Size(229, 25);
        this.comboBox3.TabIndex = 4;
        // 
        // label8
        // 
        this.label8.AutoSize = true;
        this.label8.Location = new System.Drawing.Point(7, 24);
        this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label8.Name = "label8";
        this.label8.Size = new System.Drawing.Size(26, 17);
        this.label8.TabIndex = 3;
        this.label8.Text = "по";
        // 
        // groupBox2
        // 
        this.groupBox2.Controls.Add(this.radioButton3);
        this.groupBox2.Controls.Add(this.radioButton2);
        this.groupBox2.Controls.Add(this.radioButton1);
        this.groupBox2.Location = new System.Drawing.Point(10, 352);
        this.groupBox2.Name = "groupBox2";
        this.groupBox2.Size = new System.Drawing.Size(269, 44);
        this.groupBox2.TabIndex = 1;
        this.groupBox2.TabStop = false;
        this.groupBox2.Text = "Выберите тип помещения";
        // 
        // radioButton3
        // 
        this.radioButton3.AutoSize = true;
        this.radioButton3.Location = new System.Drawing.Point(169, 21);
        this.radioButton3.Name = "radioButton3";
        this.radioButton3.Size = new System.Drawing.Size(72, 21);
        this.radioButton3.TabIndex = 2;
        this.radioButton3.Text = "Любое";
        this.radioButton3.UseVisualStyleBackColor = true;
        // 
        // radioButton2
        // 
        this.radioButton2.AutoSize = true;
        this.radioButton2.Location = new System.Drawing.Point(83, 21);
        this.radioButton2.Name = "radioButton2";
        this.radioButton2.Size = new System.Drawing.Size(86, 21);
        this.radioButton2.TabIndex = 1;
        this.radioButton2.Text = "Нежилое";
        this.radioButton2.UseVisualStyleBackColor = true;
        // 
        // radioButton1
        // 
        this.radioButton1.AutoSize = true;
        this.radioButton1.Checked = true;
        this.radioButton1.Location = new System.Drawing.Point(7, 21);
        this.radioButton1.Name = "radioButton1";
        this.radioButton1.Size = new System.Drawing.Size(73, 21);
        this.radioButton1.TabIndex = 0;
        this.radioButton1.TabStop = true;
        this.radioButton1.Text = "Жилое";
        this.radioButton1.UseVisualStyleBackColor = true;
        // 
        // groupBox10
        // 
        this.groupBox10.Controls.Add(this.numericUpDown3);
        this.groupBox10.Controls.Add(this.label5);
        this.groupBox10.Controls.Add(this.numericUpDown2);
        this.groupBox10.Controls.Add(this.label6);
        this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox10.Location = new System.Drawing.Point(10, 85);
        this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox10.Name = "groupBox10";
        this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox10.Size = new System.Drawing.Size(269, 53);
        this.groupBox10.TabIndex = 14;
        this.groupBox10.TabStop = false;
        this.groupBox10.Text = "Долг";
        // 
        // numericUpDown3
        // 
        this.numericUpDown3.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown3.Location = new System.Drawing.Point(170, 20);
        this.numericUpDown3.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown3.Name = "numericUpDown3";
        this.numericUpDown3.Size = new System.Drawing.Size(93, 23);
        this.numericUpDown3.TabIndex = 6;
        // 
        // label5
        // 
        this.label5.AutoSize = true;
        this.label5.Location = new System.Drawing.Point(138, 20);
        this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label5.Name = "label5";
        this.label5.Size = new System.Drawing.Size(29, 17);
        this.label5.TabIndex = 5;
        this.label5.Text = "До";
        // 
        // numericUpDown2
        // 
        this.numericUpDown2.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown2.Location = new System.Drawing.Point(37, 20);
        this.numericUpDown2.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown2.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown2.Name = "numericUpDown2";
        this.numericUpDown2.Size = new System.Drawing.Size(94, 23);
        this.numericUpDown2.TabIndex = 4;
        // 
        // label6
        // 
        this.label6.AutoSize = true;
        this.label6.Location = new System.Drawing.Point(7, 20);
        this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label6.Name = "label6";
        this.label6.Size = new System.Drawing.Size(28, 17);
        this.label6.TabIndex = 3;
        this.label6.Text = "От";
        // 
        // groupBox4
        // 
        this.groupBox4.Controls.Add(this.maskedTextBox1);
        this.groupBox4.Location = new System.Drawing.Point(10, 32);
        this.groupBox4.Name = "groupBox4";
        this.groupBox4.Size = new System.Drawing.Size(269, 53);
        this.groupBox4.TabIndex = 3;
        this.groupBox4.TabStop = false;
        this.groupBox4.Text = "Номер лицевого счета";
        // 
        // maskedTextBox1
        // 
        this.maskedTextBox1.BeepOnError = true;
        this.maskedTextBox1.Location = new System.Drawing.Point(7, 22);
        this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(4);
        this.maskedTextBox1.Mask = "000000000000000000";
        this.maskedTextBox1.Name = "maskedTextBox1";
        this.maskedTextBox1.PromptChar = '.';
        this.maskedTextBox1.Size = new System.Drawing.Size(257, 23);
        this.maskedTextBox1.TabIndex = 7;
        this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // groupBox12
        // 
        this.groupBox12.Controls.Add(this.numericUpDown4);
        this.groupBox12.Controls.Add(this.label7);
        this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox12.Location = new System.Drawing.Point(149, 398);
        this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox12.Name = "groupBox12";
        this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox12.Size = new System.Drawing.Size(130, 48);
        this.groupBox12.TabIndex = 16;
        this.groupBox12.TabStop = false;
        this.groupBox12.Text = "Сальдо к";
        // 
        // numericUpDown4
        // 
        this.numericUpDown4.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown4.Location = new System.Drawing.Point(38, 18);
        this.numericUpDown4.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown4.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown4.Name = "numericUpDown4";
        this.numericUpDown4.Size = new System.Drawing.Size(87, 23);
        this.numericUpDown4.TabIndex = 4;
        // 
        // label7
        // 
        this.label7.AutoSize = true;
        this.label7.Location = new System.Drawing.Point(7, 20);
        this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label7.Name = "label7";
        this.label7.Size = new System.Drawing.Size(28, 17);
        this.label7.TabIndex = 3;
        this.label7.Text = "От";
        // 
        // groupBox9
        // 
        this.groupBox9.Controls.Add(this.label10);
        this.groupBox9.Controls.Add(this.numericUpDown1);
        this.groupBox9.Controls.Add(this.label3);
        this.groupBox9.Controls.Add(this.label4);
        this.groupBox9.Controls.Add(this.textBox3);
        this.groupBox9.Controls.Add(this.comboBox2);
        this.groupBox9.Controls.Add(this.radioButton4);
        this.groupBox9.Controls.Add(this.radioButton7);
        this.groupBox9.Location = new System.Drawing.Point(10, 188);
        this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox9.Name = "groupBox9";
        this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox9.Size = new System.Drawing.Size(269, 109);
        this.groupBox9.TabIndex = 12;
        this.groupBox9.TabStop = false;
        this.groupBox9.Text = "Адрес";
        // 
        // label10
        // 
        this.label10.AutoSize = true;
        this.label10.Location = new System.Drawing.Point(7, 81);
        this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label10.Name = "label10";
        this.label10.Size = new System.Drawing.Size(35, 17);
        this.label10.TabIndex = 16;
        this.label10.Text = "Дом";
        // 
        // numericUpDown1
        // 
        this.numericUpDown1.Location = new System.Drawing.Point(82, 79);
        this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
        this.numericUpDown1.Name = "numericUpDown1";
        this.numericUpDown1.Size = new System.Drawing.Size(66, 23);
        this.numericUpDown1.TabIndex = 15;
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(151, 81);
        this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(16, 17);
        this.label3.TabIndex = 14;
        this.label3.Text = "К";
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Location = new System.Drawing.Point(50, 81);
        this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(24, 17);
        this.label4.TabIndex = 13;
        this.label4.Text = "№";
        // 
        // textBox3
        // 
        this.textBox3.Location = new System.Drawing.Point(170, 78);
        this.textBox3.Margin = new System.Windows.Forms.Padding(4);
        this.textBox3.Name = "textBox3";
        this.textBox3.Size = new System.Drawing.Size(32, 23);
        this.textBox3.TabIndex = 12;
        // 
        // comboBox2
        // 
        this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBox2.Enabled = false;
        this.comboBox2.FormattingEnabled = true;
        this.comboBox2.Location = new System.Drawing.Point(7, 49);
        this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox2.MaxDropDownItems = 12;
        this.comboBox2.Name = "comboBox2";
        this.comboBox2.Size = new System.Drawing.Size(256, 24);
        this.comboBox2.TabIndex = 11;
        // 
        // radioButton4
        // 
        this.radioButton4.AutoSize = true;
        this.radioButton4.Location = new System.Drawing.Point(128, 20);
        this.radioButton4.Margin = new System.Windows.Forms.Padding(4);
        this.radioButton4.Name = "radioButton4";
        this.radioButton4.Size = new System.Drawing.Size(105, 21);
        this.radioButton4.TabIndex = 3;
        this.radioButton4.TabStop = true;
        this.radioButton4.Text = "Выбранная:";
        this.radioButton4.UseVisualStyleBackColor = true;
        this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
        // 
        // radioButton7
        // 
        this.radioButton7.AutoSize = true;
        this.radioButton7.Checked = true;
        this.radioButton7.Location = new System.Drawing.Point(7, 20);
        this.radioButton7.Margin = new System.Windows.Forms.Padding(4);
        this.radioButton7.Name = "radioButton7";
        this.radioButton7.Size = new System.Drawing.Size(113, 21);
        this.radioButton7.TabIndex = 2;
        this.radioButton7.TabStop = true;
        this.radioButton7.Text = "Улица любая";
        this.radioButton7.UseVisualStyleBackColor = true;
        this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
        // 
        // groupBox5
        // 
        this.groupBox5.Controls.Add(this.textBox1);
        this.groupBox5.Location = new System.Drawing.Point(10, 135);
        this.groupBox5.Name = "groupBox5";
        this.groupBox5.Size = new System.Drawing.Size(269, 53);
        this.groupBox5.TabIndex = 4;
        this.groupBox5.TabStop = false;
        this.groupBox5.Text = "ФИО";
        // 
        // textBox1
        // 
        this.textBox1.Location = new System.Drawing.Point(7, 22);
        this.textBox1.Margin = new System.Windows.Forms.Padding(4);
        this.textBox1.Name = "textBox1";
        this.textBox1.Size = new System.Drawing.Size(256, 23);
        this.textBox1.TabIndex = 1;
        // 
        // groupBox11
        // 
        this.groupBox11.Controls.Add(this.numericUpDown5);
        this.groupBox11.Controls.Add(this.label9);
        this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.groupBox11.Location = new System.Drawing.Point(10, 398);
        this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox11.Name = "groupBox11";
        this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox11.Size = new System.Drawing.Size(132, 48);
        this.groupBox11.TabIndex = 15;
        this.groupBox11.TabStop = false;
        this.groupBox11.Text = "Сальдо н";
        // 
        // numericUpDown5
        // 
        this.numericUpDown5.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.numericUpDown5.Location = new System.Drawing.Point(38, 18);
        this.numericUpDown5.Margin = new System.Windows.Forms.Padding(4);
        this.numericUpDown5.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
        this.numericUpDown5.Name = "numericUpDown5";
        this.numericUpDown5.Size = new System.Drawing.Size(87, 23);
        this.numericUpDown5.TabIndex = 4;
        // 
        // label9
        // 
        this.label9.AutoSize = true;
        this.label9.Location = new System.Drawing.Point(7, 20);
        this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label9.Name = "label9";
        this.label9.Size = new System.Drawing.Size(28, 17);
        this.label9.TabIndex = 3;
        this.label9.Text = "От";
        // 
        // groupBox3
        // 
        this.groupBox3.Controls.Add(this.radioButton5);
        this.groupBox3.Controls.Add(this.comboBox1);
        this.groupBox3.Controls.Add(this.radioButton6);
        this.groupBox3.Location = new System.Drawing.Point(10, 297);
        this.groupBox3.Name = "groupBox3";
        this.groupBox3.Size = new System.Drawing.Size(269, 53);
        this.groupBox3.TabIndex = 2;
        this.groupBox3.TabStop = false;
        this.groupBox3.Text = "Выберите обсл. организацию";
        // 
        // radioButton5
        // 
        this.radioButton5.AutoSize = true;
        this.radioButton5.Location = new System.Drawing.Point(55, 22);
        this.radioButton5.Name = "radioButton5";
        this.radioButton5.Size = new System.Drawing.Size(67, 21);
        this.radioButton5.TabIndex = 13;
        this.radioButton5.TabStop = true;
        this.radioButton5.Text = "Выбр.";
        this.radioButton5.UseVisualStyleBackColor = true;
        this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
        // 
        // comboBox1
        // 
        this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBox1.Enabled = false;
        this.comboBox1.FormattingEnabled = true;
        this.comboBox1.Location = new System.Drawing.Point(127, 21);
        this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox1.MaxDropDownItems = 12;
        this.comboBox1.Name = "comboBox1";
        this.comboBox1.Size = new System.Drawing.Size(135, 24);
        this.comboBox1.TabIndex = 12;
        // 
        // radioButton6
        // 
        this.radioButton6.AutoSize = true;
        this.radioButton6.Checked = true;
        this.radioButton6.Location = new System.Drawing.Point(7, 22);
        this.radioButton6.Name = "radioButton6";
        this.radioButton6.Size = new System.Drawing.Size(50, 21);
        this.radioButton6.TabIndex = 0;
        this.radioButton6.TabStop = true;
        this.radioButton6.Text = "Все";
        this.radioButton6.UseVisualStyleBackColor = true;
        this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.label1.Location = new System.Drawing.Point(7, 9);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(164, 20);
        this.label1.TabIndex = 0;
        this.label1.Text = "Фильтры поиска";
        // 
        // splitContainer2
        // 
        this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
        this.splitContainer2.Location = new System.Drawing.Point(0, 0);
        this.splitContainer2.Name = "splitContainer2";
        // 
        // splitContainer2.Panel1
        // 
        this.splitContainer2.Panel1.Controls.Add(this.groupBox6);
        this.splitContainer2.Panel1.Controls.Add(this.label2);
        // 
        // splitContainer2.Panel2
        // 
        this.splitContainer2.Panel2.AutoScroll = true;
        this.splitContainer2.Panel2.Controls.Add(this.label11);
        this.splitContainer2.Panel2.Controls.Add(this.groupBox7);
        this.splitContainer2.Panel2.Controls.Add(this.richTextBox1);
        this.splitContainer2.Size = new System.Drawing.Size(567, 558);
        this.splitContainer2.SplitterDistance = 249;
        this.splitContainer2.TabIndex = 0;
        // 
        // groupBox6
        // 
        this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                    | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox6.Controls.Add(this.selLSDataGridView);
        this.groupBox6.Location = new System.Drawing.Point(3, 28);
        this.groupBox6.Name = "groupBox6";
        this.groupBox6.Size = new System.Drawing.Size(242, 521);
        this.groupBox6.TabIndex = 4;
        this.groupBox6.TabStop = false;
        this.groupBox6.Text = "Найдено";
        // 
        // selLSDataGridView
        // 
        this.selLSDataGridView.AllowUserToAddRows = false;
        this.selLSDataGridView.AllowUserToDeleteRows = false;
        this.selLSDataGridView.AllowUserToOrderColumns = true;
        this.selLSDataGridView.AllowUserToResizeRows = false;
        this.selLSDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
        this.selLSDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.selLSDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ITGNW,
            this.PEN_S1,
            this.SAL1W,
            this.SAL2W});
        this.selLSDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
        this.selLSDataGridView.Location = new System.Drawing.Point(3, 19);
        this.selLSDataGridView.MultiSelect = false;
        this.selLSDataGridView.Name = "selLSDataGridView";
        this.selLSDataGridView.ReadOnly = true;
        this.selLSDataGridView.RowTemplate.Height = 24;
        this.selLSDataGridView.Size = new System.Drawing.Size(236, 499);
        this.selLSDataGridView.TabIndex = 3;
        // 
        // ITGNW
        // 
        this.ITGNW.DataPropertyName = "ITGNW";
        this.ITGNW.HeaderText = "Долг";
        this.ITGNW.Name = "ITGNW";
        this.ITGNW.ReadOnly = true;
        this.ITGNW.Width = 65;
        // 
        // PEN_S1
        // 
        this.PEN_S1.DataPropertyName = "PEN_S1";
        this.PEN_S1.HeaderText = "Пеня";
        this.PEN_S1.Name = "PEN_S1";
        this.PEN_S1.ReadOnly = true;
        this.PEN_S1.Width = 64;
        // 
        // SAL1W
        // 
        this.SAL1W.DataPropertyName = "SAL1W";
        this.SAL1W.HeaderText = "СальдоН";
        this.SAL1W.Name = "SAL1W";
        this.SAL1W.ReadOnly = true;
        this.SAL1W.Width = 88;
        // 
        // SAL2W
        // 
        this.SAL2W.DataPropertyName = "SAL2W";
        this.SAL2W.HeaderText = "СальдоК";
        this.SAL2W.Name = "SAL2W";
        this.SAL2W.ReadOnly = true;
        this.SAL2W.Width = 87;
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.label2.Location = new System.Drawing.Point(0, 5);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(189, 20);
        this.label2.TabIndex = 3;
        this.label2.Text = "Результаты поиска";
        // 
        // label11
        // 
        this.label11.AutoSize = true;
        this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.label11.Location = new System.Drawing.Point(3, 5);
        this.label11.Name = "label11";
        this.label11.Size = new System.Drawing.Size(262, 20);
        this.label11.TabIndex = 4;
        this.label11.Text = "Просмотр/редактирование";
        // 
        // groupBox7
        // 
        this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox7.Controls.Add(this.fIOLabel1);
        this.groupBox7.Location = new System.Drawing.Point(4, 28);
        this.groupBox7.Name = "groupBox7";
        this.groupBox7.Size = new System.Drawing.Size(306, 138);
        this.groupBox7.TabIndex = 1;
        this.groupBox7.TabStop = false;
        this.groupBox7.Text = "Комментарии";
        // 
        // fIOLabel1
        // 
        this.fIOLabel1.AutoSize = true;
        this.fIOLabel1.Location = new System.Drawing.Point(6, 19);
        this.fIOLabel1.Name = "fIOLabel1";
        this.fIOLabel1.Size = new System.Drawing.Size(37, 17);
        this.fIOLabel1.TabIndex = 1;
        this.fIOLabel1.Text = "ФИО";
        // 
        // richTextBox1
        // 
        this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
        this.richTextBox1.Location = new System.Drawing.Point(0, 491);
        this.richTextBox1.Name = "richTextBox1";
        this.richTextBox1.ReadOnly = true;
        this.richTextBox1.Size = new System.Drawing.Size(310, 63);
        this.richTextBox1.TabIndex = 0;
        this.richTextBox1.Text = "";
        // 
        // archiveDataSet
        // 
        this.archiveDataSet.DataSetName = "archiveDataSet";
        this.archiveDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
        // 
        // selLSBindingSource
        // 
        this.selLSBindingSource.DataMember = "selLS";
        this.selLSBindingSource.DataSource = this.archiveDataSet;
        // 
        // selLSTableAdapter
        // 
        this.selLSTableAdapter.ClearBeforeFill = true;
        // 
        // tableAdapterManager
        // 
        this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
        this.tableAdapterManager.Connection = null;
        // 
        // bindingNavigator1
        // 
        this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
        this.bindingNavigator1.BindingSource = this.selLSBindingSource;
        this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
        this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
        this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem});
        this.bindingNavigator1.Location = new System.Drawing.Point(0, 28);
        this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
        this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
        this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
        this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
        this.bindingNavigator1.Name = "bindingNavigator1";
        this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
        this.bindingNavigator1.Size = new System.Drawing.Size(865, 27);
        this.bindingNavigator1.TabIndex = 3;
        this.bindingNavigator1.Text = "bindingNavigator1";
        // 
        // bindingNavigatorMoveFirstItem
        // 
        this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
        this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
        this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
        this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
        // 
        // bindingNavigatorMovePreviousItem
        // 
        this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
        this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
        this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
        this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
        // 
        // bindingNavigatorSeparator
        // 
        this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
        this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
        // 
        // bindingNavigatorPositionItem
        // 
        this.bindingNavigatorPositionItem.AccessibleName = "Положение";
        this.bindingNavigatorPositionItem.AutoSize = false;
        this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
        this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
        this.bindingNavigatorPositionItem.Text = "0";
        this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
        // 
        // bindingNavigatorCountItem
        // 
        this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
        this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 20);
        this.bindingNavigatorCountItem.Text = "для {0}";
        this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
        // 
        // bindingNavigatorSeparator1
        // 
        this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
        this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
        // 
        // bindingNavigatorMoveNextItem
        // 
        this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
        this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
        this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
        this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
        // 
        // bindingNavigatorMoveLastItem
        // 
        this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
        this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
        this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
        this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
        // 
        // bindingNavigatorSeparator2
        // 
        this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
        this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
        // 
        // bindingNavigatorAddNewItem
        // 
        this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
        this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
        this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 24);
        this.bindingNavigatorAddNewItem.Text = "Добавить";
        // 
        // bindingNavigatorDeleteItem
        // 
        this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
        this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
        this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
        this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
        this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
        this.bindingNavigatorDeleteItem.Text = "Удалить";
        // 
        // FMain
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.AutoScroll = true;
        this.ClientSize = new System.Drawing.Size(865, 630);
        this.Controls.Add(this.bindingNavigator1);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.statusStrip1);
        this.Controls.Add(this.menuStrip1);
        this.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.MainMenuStrip = this.menuStrip1;
        this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
        this.Name = "FMain";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Работа с должниками";
        this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        this.Load += new System.EventHandler(this.FMain_Load);
        this.menuStrip1.ResumeLayout(false);
        this.menuStrip1.PerformLayout();
        this.groupBox1.ResumeLayout(false);
        this.splitContainer1.Panel1.ResumeLayout(false);
        this.splitContainer1.Panel1.PerformLayout();
        this.splitContainer1.Panel2.ResumeLayout(false);
        this.splitContainer1.ResumeLayout(false);
        this.groupBox13.ResumeLayout(false);
        this.groupBox13.PerformLayout();
        this.groupBox2.ResumeLayout(false);
        this.groupBox2.PerformLayout();
        this.groupBox10.ResumeLayout(false);
        this.groupBox10.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
        this.groupBox4.ResumeLayout(false);
        this.groupBox4.PerformLayout();
        this.groupBox12.ResumeLayout(false);
        this.groupBox12.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
        this.groupBox9.ResumeLayout(false);
        this.groupBox9.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
        this.groupBox5.ResumeLayout(false);
        this.groupBox5.PerformLayout();
        this.groupBox11.ResumeLayout(false);
        this.groupBox11.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
        this.groupBox3.ResumeLayout(false);
        this.groupBox3.PerformLayout();
        this.splitContainer2.Panel1.ResumeLayout(false);
        this.splitContainer2.Panel1.PerformLayout();
        this.splitContainer2.Panel2.ResumeLayout(false);
        this.splitContainer2.Panel2.PerformLayout();
        this.splitContainer2.ResumeLayout(false);
        this.groupBox6.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.selLSDataGridView)).EndInit();
        this.groupBox7.ResumeLayout(false);
        this.groupBox7.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.archiveDataSet)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.selLSBindingSource)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
        this.bindingNavigator1.ResumeLayout(false);
        this.bindingNavigator1.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ToolStripMenuItem начатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem начатьРаботуToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView selLSDataGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ITGNW;
        private System.Windows.Forms.DataGridViewTextBoxColumn PEN_S1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAL1W;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAL2W;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label fIOLabel1;
        private archiveDataSet archiveDataSet;
        private System.Windows.Forms.BindingSource selLSBindingSource;
        private archiveDataSetTableAdapters.selLSTableAdapter selLSTableAdapter;
        private archiveDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
    }
}

